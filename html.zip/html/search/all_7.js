var searchData=
[
  ['rook_5fattack',['rook_attack',['../class_game_board.html#aaf6b88ae6909753f183c6cf503876368',1,'GameBoard']]]
];
