var searchData=
[
  ['youdied',['youdied',['../classyoudied.html',1,'']]]
];
