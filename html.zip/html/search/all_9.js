var searchData=
[
  ['updateplayer',['updatePlayer',['../class_game_board.html#a81c1403660efcbf4b020302baa6d6f7d',1,'GameBoard']]],
  ['updatewalkers',['updateWalkers',['../class_game_board.html#a4fc2d065da3e271196986e66ba718356',1,'GameBoard']]]
];
