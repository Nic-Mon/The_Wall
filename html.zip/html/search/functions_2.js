var searchData=
[
  ['gameover',['gameOver',['../class_game_board.html#af7b41965116369364da14dd272d06b7d',1,'GameBoard']]]
];
