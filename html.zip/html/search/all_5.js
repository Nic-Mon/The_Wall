var searchData=
[
  ['new_5fgame',['new_game',['../classyoudied.html#a810c37ac90a3c4d678aeae834648ecc9',1,'youdied']]]
];
