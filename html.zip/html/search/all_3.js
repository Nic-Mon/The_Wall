var searchData=
[
  ['knight_5fattack',['knight_attack',['../class_game_board.html#ada713f255e522b2e34c86b6e6868fca7',1,'GameBoard']]]
];
