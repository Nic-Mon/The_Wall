var searchData=
[
  ['queen_5fattack',['queen_attack',['../class_game_board.html#a9c470a5c1cdcf1b7217b4a4585cf8bd9',1,'GameBoard']]],
  ['quit_5fgame',['quit_game',['../classyoudied.html#af55f8fd47ce780437cceea7d2788adaa',1,'youdied']]]
];
