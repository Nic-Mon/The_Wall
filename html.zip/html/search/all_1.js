var searchData=
[
  ['bishop_5fattack',['bishop_attack',['../class_game_board.html#afdc9c6ebaa8069ec6aeacada17df58bd',1,'GameBoard']]]
];
